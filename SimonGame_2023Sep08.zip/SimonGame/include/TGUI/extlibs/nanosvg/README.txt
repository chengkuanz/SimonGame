The official nanosvg repository can be found at https://github.com/memononen/nanosvg

The headers used here were however taken from https://github.com/fltk/fltk/tree/master/nanosvg because we need the additional functionality of scaling X and Y directions separately.
