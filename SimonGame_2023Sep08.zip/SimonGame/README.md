# SimonGame
Simon is a short-term memory skill game created using C++ and utilizes the TGUI and SFML libraries. 
